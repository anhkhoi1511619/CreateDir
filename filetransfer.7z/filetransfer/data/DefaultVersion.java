package jp.co.lecip.livumanagerapp.aws.filetransfer.data;

public class DefaultVersion {
    public String id;
    public String version;
    public String url;

    public DefaultVersion(String id, String version, String url) {
        this.id = id;
        this.version = version;
        this.url = url;
    }
}
